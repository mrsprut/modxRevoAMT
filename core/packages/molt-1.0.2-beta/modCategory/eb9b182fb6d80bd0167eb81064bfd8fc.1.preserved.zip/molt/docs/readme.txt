--------------------
molt
--------------------
Author: Andrei Gadashevich <gav.andrei@makebecool.com>
--------------------

This extension to minify and deferred js and css file

Feel free to suggest ideas/improvements/bugs on GitHub:
https://github.com/MakeBeCool/Molt/issues