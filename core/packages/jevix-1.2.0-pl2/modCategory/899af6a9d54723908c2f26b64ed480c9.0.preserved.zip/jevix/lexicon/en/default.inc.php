<?php

$_lang['jevix'] = 'Jevix';