<?php
/**
 * @package modextra
 */
$o = include dirname(__FILE__).'/controllers/index.php';
return $o;