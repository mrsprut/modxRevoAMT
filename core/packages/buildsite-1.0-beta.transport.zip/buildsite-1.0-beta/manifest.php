<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'chunks' => 
    array (
      'orderFormTours' => '',
      'galleryOuterTours' => '',
      'galleryItemTours' => '',
    ),
    'setup-options' => 'buildsite-1.0-beta/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e09f0bbcce3a4aa6dc5239ebdbc5cd2',
      'native_key' => 'basetheme.index',
      'filename' => 'modSystemSetting/2cbb9f87bd21b19e17931d2e5a0e7415.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a949f1251e74b7bfb9e25dac27521962',
      'native_key' => 'basetheme.about',
      'filename' => 'modSystemSetting/6781c74d807a3ce513657ff3dd58d557.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc784ece393fc0fb53540f5d0a9e25bd',
      'native_key' => 'basetheme.eventsList',
      'filename' => 'modSystemSetting/4f8ba6423b21ce1b4a39b1c83f656ccb.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2862036d97f3e2682cddb8668e25119',
      'native_key' => 'basetheme.event',
      'filename' => 'modSystemSetting/cdd955fb799f6c5712be7dc7966d5e31.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da52156aef652e13b53c2a7c68cd9bba',
      'native_key' => 'basetheme.tours',
      'filename' => 'modSystemSetting/38d030f614f8b37f53500bd0a5845f1b.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '1679fdabaff0c64b0a46b6cb0274d646',
      'native_key' => NULL,
      'filename' => 'modCategory/769d1b06ba9d452b5f0a595ae7334db7.vehicle',
    ),
  ),
);