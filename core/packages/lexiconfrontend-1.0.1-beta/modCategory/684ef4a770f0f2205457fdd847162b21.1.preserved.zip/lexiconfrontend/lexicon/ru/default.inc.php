<?php

$_lang['lf_brand_name'] = 'Base Theme';

$_lang['lf_contact_head'] = 'Напишите нам';
$_lang['lf_contact_name'] = 'Имя:';
$_lang['lf_contact_email'] = 'E-mail:';
$_lang['lf_contact_phone'] = 'Телефон:';
$_lang['lf_contact_message'] = 'Сообщение:';
$_lang['lf_contact_send'] = 'Отправить';
$_lang['lf_contact_successMessage'] = 'Спасибо, ваше сообщение отправлено';
$_lang['lf_contact_sendAnother'] = 'Отправить еще сообщение';

$_lang['lf_topmenu_copyright'] = 'COPYRIGHT © 2014 CAVIAR DE RIOFRIO S.L.';
$_lang['lf_topmenu_legalnotice'] = 'Legal notice';

$_lang['lf_index_title_production'] = 'Производство икры';
$_lang['lf_index_btn_more'] = 'Подробнее';

$_lang['lf_sender_title'] = 'Анонсы событий Вам на почту';
$_lang['lf_sender_placeholder_name'] = 'Ваше имя:';
$_lang['lf_sender_placeholder_email'] = 'Ваш e-mail:';

$_lang['lf_backcall_placeholder_name'] = 'Имя:';
$_lang['lf_backcall_placeholder_email'] = 'E-mail:';
$_lang['lf_backcall_placeholder_phone'] = 'Телефон:';
$_lang['lf_backcall_txt_message'] = 'Ваше сообщение:';

$_lang['lf_footer_copyright'] = 'COPYRIGHT © 2014 CAVIAR DE RIOFRIO S.L.';