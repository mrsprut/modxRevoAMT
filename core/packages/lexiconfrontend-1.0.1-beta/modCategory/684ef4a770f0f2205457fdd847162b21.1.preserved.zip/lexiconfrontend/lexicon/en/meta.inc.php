<?php

$_lang['lf_site_name'] = ' / BaseTheme';

$_lang['lf_description'] = 'Development templates for MODX form MakeBeCool.com design studio';