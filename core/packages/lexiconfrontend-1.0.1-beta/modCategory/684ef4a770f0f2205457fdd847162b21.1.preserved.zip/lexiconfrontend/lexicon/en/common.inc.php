<?php

$_lang['lf_page_prev'] = 'Prev';
$_lang['lf_page_next'] = 'Next';

$_lang['lf_month.01'] = 'January';
$_lang['lf_month.02'] = 'February';
$_lang['lf_month.03'] = 'March';
$_lang['lf_month.04'] = 'April';
$_lang['lf_month.05'] = 'May';
$_lang['lf_month.06'] = 'June';
$_lang['lf_month.07'] = 'July';
$_lang['lf_month.08'] = 'August';
$_lang['lf_month.09'] = 'September';
$_lang['lf_month.10'] = 'October';
$_lang['lf_month.11'] = 'November';
$_lang['lf_month.12'] = 'December';

$_lang['lf_month_short.01'] = 'Jan';
$_lang['lf_month_short.02'] = 'Feb';
$_lang['lf_month_short.03'] = 'Mar';
$_lang['lf_month_short.04'] = 'Apr';
$_lang['lf_month_short.05'] = 'May';
$_lang['lf_month_short.06'] = 'Jun';
$_lang['lf_month_short.07'] = 'Jul';
$_lang['lf_month_short.08'] = 'Aug';
$_lang['lf_month_short.09'] = 'Sep';
$_lang['lf_month_short.10'] = 'Oct';
$_lang['lf_month_short.11'] = 'Nov';
$_lang['lf_month_short.12'] = 'Dec';

$_lang['lf_week.0']='Mo';
$_lang['lf_week.1']='Tu';
$_lang['lf_week.2']='We';
$_lang['lf_week.3']='Th';
$_lang['lf_week.4']='Fr';
$_lang['lf_week.5']='Sa';
$_lang['lf_week.6']='Su';