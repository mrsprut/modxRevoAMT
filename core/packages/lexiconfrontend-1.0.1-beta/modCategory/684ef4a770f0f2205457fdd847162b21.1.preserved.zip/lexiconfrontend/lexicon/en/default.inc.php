<?php

$_lang['lf_brand_name'] = 'Base Theme';

$_lang['lf_contact_head'] = 'Write to us';
$_lang['lf_contact_name'] = 'Name:';
$_lang['lf_contact_email'] = 'E-mail:';
$_lang['lf_contact_phone'] = ':';
$_lang['lf_contact_message'] = 'Message:';
$_lang['lf_contact_send'] = 'Send';
$_lang['lf_contact_successMessage'] = 'Thank you, your message has been sent.';
$_lang['lf_contact_sendAnother'] = 'Send another message';