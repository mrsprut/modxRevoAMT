<?php

$properties = array();


return $properties;