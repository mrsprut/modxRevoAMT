<?php

$_lang['lexiconfrontend'] = 'Lexicon Frontend';
$_lang['lexiconfrontend_menu_desc'] = 'Лексикон для фронтенда';
$_lang['lf_title'] = 'Lexicon Frontend';
$_lang['lf_title_tab'] = 'Словарь';
$_lang['lf_description'] = 'Изменение языковых строк в шаблоне';