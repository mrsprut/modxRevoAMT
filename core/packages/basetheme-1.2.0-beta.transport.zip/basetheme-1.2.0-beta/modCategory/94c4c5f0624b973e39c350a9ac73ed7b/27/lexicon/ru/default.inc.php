<?php

$_lang['lf_brand_name'] = 'Base Theme';

$_lang['lf_contact_head'] = 'Напишите нам';
$_lang['lf_contact_name'] = 'Имя:';
$_lang['lf_contact_email'] = 'E-mail:';
$_lang['lf_contact_phone'] = 'Телефон:';
$_lang['lf_contact_message'] = 'Сообщение:';
$_lang['lf_contact_send'] = 'Отправить';
$_lang['lf_contact_successMessage'] = 'Спасибо, ваше сообщение отправлено';
$_lang['lf_contact_sendAnother'] = 'Отправить еще сообщение';