<?php

$_lang['lf_site_name'] = ' / Базовый шаблон';

$_lang['lf_description'] = 'Разработка шаблонов для  MODX от MakeBeCool.com';