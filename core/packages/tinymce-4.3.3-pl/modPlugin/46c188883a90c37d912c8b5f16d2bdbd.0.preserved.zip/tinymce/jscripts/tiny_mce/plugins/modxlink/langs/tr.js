tinyMCE.addI18n('tr.modxlink',{
    link_desc:"Insert/edit link"
});