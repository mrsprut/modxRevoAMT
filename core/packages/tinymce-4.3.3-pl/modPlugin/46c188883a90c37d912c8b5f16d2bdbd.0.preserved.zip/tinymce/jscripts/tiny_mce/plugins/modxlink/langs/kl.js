tinyMCE.addI18n('kl.modxlink',{
    link_desc:"Insert/edit link"
});